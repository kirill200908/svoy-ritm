import { test } from 'node:test';
import assert from 'node:assert/strict';
import { handleSchools, parseDiary, sealSession, openSession, openBrowserSession } from './schools.mjs';
const secret = Buffer.alloc(32, 7).toString('base64');
const env = { SCHOOLS_SESSION_KEY: secret, SCHOOLS_HOST: 'lyceum.schools.by', SCHOOLS_PUPIL_ID: '12345' };
const site = 'https://test.example';
const day = new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Minsk',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
function fixture(value = 10) { return `<div class="db_days clearfix"><div class="db_day" data-date="${day}"><h3>Сегодня</h3><table><tbody><tr><td class="lesson">1. Математика</td><td><div class="mark_box"><span>${value}</span></div></td><td>ДЗ: 10 упражнений</td></tr><tr><td class="lesson">2. Физика</td><td><div class="mark_box">9/10</div></td></tr></tbody></table></div></div>`; }
let counter = 0;
function request(path, init = {}) { return new Request(site + '/api/schools/' + path, { ...init, headers: { origin:site, 'content-type':'application/json', 'cf-connecting-ip':'192.0.2.'+(++counter), ...init.headers } }); }
function cookies(response) { return response.headers.getSetCookie(); }
function pair(value) { return value.split(';')[0]; }
function token(value) { return pair(value).split('=').slice(1).join('='); }
function schoolCookie(response) { return cookies(response).find(c=>c.startsWith('__Secure-rhythm-school=')); }
async function browser(headers={}) {
  const response=await handleSchools(request('status',{headers}),env);
  assert.equal(response.status,200);
  const cookie=cookies(response).find(c=>c.startsWith('__Secure-rhythm-browser='));assert.ok(cookie);
  return {cookie:pair(cookie),token:token(cookie)};
}
function mockLogin(calls=[]) { return async(url,init)=>{
  calls.push({url,init});
  if(url==='https://schools.by/login' && init.method==='POST') return new Response(null,{status:302,headers:{location:'https://lyceum.schools.by/pupil/12345','set-cookie':'sessionid=test-session; Path=/; Secure'}});
  if(url==='https://schools.by/login') return new Response('<form><input name="csrfmiddlewaretoken" value="test-csrf"><input name="password"></form>',{headers:{'set-cookie':'csrftoken=test-csrf; Path=/; Secure'}});
  return new Response(fixture());
}; }
const credentials=()=>JSON.stringify({username:'test-login',password:'dummy-password-for-test'});
test('HTML parser reads only actual grade cells and keeps split marks', async () => {
  const result = await parseDiary(fixture(), 'https://lyceum.schools.by/pupil/12345/dnevnik', '12345');
  assert.equal(result.grades.length, 3); assert.deepEqual(result.grades.map(g=>g.value),[10,9,10]);
  assert.equal(result.grades[0].subject,'Математика'); assert.equal(result.grades[0].date,day);
});
test('mobile and desktop copies do not award the same grades twice', async () => {
  const result = await parseDiary(fixture()+fixture(),'https://lyceum.schools.by/pupil/12345/dnevnik','12345'); assert.equal(result.grades.length,3);
});
test('a corrected grade retains the same source ID', async () => {
  const first=await parseDiary(fixture(10),'https://lyceum.schools.by/pupil/12345/dnevnik','12345');
  const corrected=await parseDiary(fixture(9),'https://lyceum.schools.by/pupil/12345/dnevnik','12345');assert.equal(first.grades[0].id,corrected.grades[0].id);
});
test('login pages and unknown layouts fail instead of returning empty success', async () => {
  await assert.rejects(()=>parseDiary('<input name="password">',site,'12345'),e=>e.code==='session_expired');
  await assert.rejects(()=>parseDiary('<div>Успеваемость 10</div>',site,'12345'),e=>e.code==='layout_changed');
  await assert.rejects(()=>parseDiary('<div class="db_day"><table><tr><td class="lesson">Математика</td><td><div class="mark_box">10</div></td></tr></table></div>',site,'12345'),e=>e.code==='layout_changed');
});
test('sessions are encrypted and bound to the visitor and site', async () => {
  const data={jar:{sessionid:'private-upstream-cookie'},expires:Date.now()+60000};
  const sealed=await sealSession(data,secret,site+'|user1');assert.ok(!sealed.includes('private-upstream-cookie'));
  assert.deepEqual(await openSession(sealed,secret,site+'|user1'),data);
  assert.equal(await openSession(sealed,secret,site+'|user2'),null);
  assert.equal(await openSession(sealed+'x',secret,site+'|user1'),null);
  assert.equal(await openSession(sealed+'.extra',secret,site+'|user1'),null);
});
test('expired session cannot be reused',async()=>{
  const sealed=await sealSession({jar:{sessionid:'old'},expires:Date.now()-1},secret,site+'|user');assert.equal(await openSession(sealed,secret,site+'|user'),null);
});
test('anonymous visitors can open the login form without a ChatGPT account',async()=>{
  let calls=0;const response=await handleSchools(new Request(site+'/api/schools/status'),env,()=>{calls++;});
  assert.equal(response.status,200);const data=await response.json();assert.equal(data.connected,false);assert.equal(data.signInUrl,undefined);assert.equal(data.grades,undefined);assert.equal(calls,0);
  assert.equal(cookies(response).length,1);assert.match(cookies(response)[0],/HttpOnly; Secure; SameSite=Strict/);
});
test('anonymous grade reads require a successful Schools.by login',async()=>{
  const client=await browser();let calls=0;const response=await handleSchools(request('grades',{method:'POST',headers:{cookie:client.cookie},body:'{}'}),env,()=>{calls++;});
  assert.equal(response.status,401);assert.equal((await response.json()).error,'session_expired');assert.equal(calls,0);
});
test('credential submission without browser cookies is rejected before upstream access',async()=>{
  let calls=0;const response=await handleSchools(request('connect',{method:'POST',body:credentials()}),env,()=>{calls++;});assert.equal(response.status,409);assert.equal(calls,0);assert.equal((await response.json()).error,'browser_session_missing');
});
test('cross-origin requests cannot initialize or change diary sessions',async()=>{
  let calls=0;
  for(const [path,init] of [['connect',{method:'POST',headers:{origin:'https://other.example'},body:credentials()}],['status',{headers:{'sec-fetch-site':'cross-site'}}]]) {
    const response=await handleSchools(request(path,init),env,()=>{calls++;});assert.equal(response.status,403);assert.equal(response.headers.get('set-cookie'),null);
  }
  assert.equal(calls,0);
});
test('login without ChatGPT validates the pupil diary and stores only a sealed upstream session',async()=>{
  const client=await browser();const calls=[];
  const response=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie},body:credentials()}),env,mockLogin(calls));
  assert.equal(response.status,200);const result=await response.json();assert.equal(result.connected,true);assert.equal(result.grades.length,3);
  assert.equal(new URLSearchParams(calls[1].init.body).get('username'),'test-login');assert.equal(calls[1].url,'https://schools.by/login');
  const cookie=schoolCookie(response);assert.ok(cookie);assert.match(cookie,/HttpOnly; Secure; SameSite=Strict/);assert.ok(!cookie.includes('dummy-password-for-test'));
  const identity=await openBrowserSession(client.token,secret,site);
  const saved=await openSession(token(cookie),secret,site+'|browser|'+identity.id);
  assert.equal(saved.jar.sessionid,'test-session');assert.equal(saved.password,undefined);assert.equal(saved.username,undefined);
  assert.match(response.headers.get('cache-control'),/no-store/);
  const allCookies=client.cookie+'; '+pair(cookie);
  const status=await handleSchools(request('status',{headers:{cookie:allCookies}}),env);assert.equal((await status.json()).connected,true);
  const grades=await handleSchools(request('grades',{method:'POST',headers:{cookie:allCookies},body:'{}'}),env,mockLogin());assert.equal(grades.status,200);assert.equal((await grades.json()).grades.length,3);
});
test('copying an upstream session to another browser does not expose grades',async()=>{
  const first=await browser(),second=await browser();
  const connected=await handleSchools(request('connect',{method:'POST',headers:{cookie:first.cookie},body:credentials()}),env,mockLogin());
  let calls=0;const wrong=await handleSchools(request('grades',{method:'POST',headers:{cookie:second.cookie+'; '+pair(schoolCookie(connected))},body:'{}'}),env,()=>{calls++;});
  assert.equal(wrong.status,401);assert.equal(calls,0);assert.equal((await wrong.json()).grades,undefined);
});
test('forged and expired browser identities cannot be used to log in',async()=>{
  const old=await sealSession({type:'browser',id:'1'.repeat(64),expires:Date.now()-1},secret,site+'|browser-identity-v1');
  for(const value of ['forged',old]) {
    let calls=0;const response=await handleSchools(request('connect',{method:'POST',headers:{cookie:'__Secure-rhythm-browser='+value},body:credentials()}),env,()=>{calls++;});assert.equal(response.status,409);assert.equal(calls,0);
  }
});
test('browser identities cannot be replayed on another origin',async()=>{
  const client=await browser();assert.equal(await openBrowserSession(client.token,secret,'https://other.example'),null);
});
test('legacy connections migrate to the browser without requiring a new login',async()=>{
  const upstream={jar:{sessionid:'previous-session'},expires:Date.now()+60000};
  const old=await sealSession(upstream,secret,site+'|old-owner');
  const response=await handleSchools(request('status',{headers:{cookie:'__Secure-rhythm-school='+old,'oai-authenticated-user-id':'old-owner'}}),env);
  assert.equal((await response.json()).connected,true);assert.equal(cookies(response).length,2);
  const current=cookies(response).map(pair).join('; ');
  const next=await handleSchools(request('status',{headers:{cookie:current}}),env);assert.equal((await next.json()).connected,true);
});
test('unavailable Schools.by gives an error and never saves an authenticated session',async()=>{
  const client=await browser();const response=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie},body:credentials()}),env,async()=>{throw new Error('upstream unavailable');});
  assert.equal(response.status,503);assert.equal(response.headers.get('set-cookie'),null);assert.equal((await response.json()).error,'upstream_unavailable');
});
test('captcha stops before credentials are sent',async()=>{
  const client=await browser();let calls=0;const response=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie},body:credentials()}),env,async()=>{calls++;return new Response('<div class="g-recaptcha"></div>');});
  assert.equal(response.status,409);assert.equal(calls,1);assert.equal(response.headers.get('set-cookie'),null);
});
test('rapid repeat login attempts from the same browser are limited',async()=>{
  const client=await browser();let calls=0;const fetcher=async()=>{calls++;return new Response('<div class="g-recaptcha"></div>');};
  const first=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie},body:credentials()}),env,fetcher);assert.equal(first.status,409);
  const second=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie},body:credentials()}),env,fetcher);assert.equal(second.status,429);assert.equal(calls,1);
});
test('a network cannot evade login limits by minting new browser cookies',async()=>{
  const ip='192.0.2.220';let calls=0;const fetcher=async()=>{calls++;return new Response('<div class="g-recaptcha"></div>');};
  for(let i=0;i<11;i++) {
    const client=await browser({'cf-connecting-ip':ip});
    const response=await handleSchools(request('connect',{method:'POST',headers:{cookie:client.cookie,'cf-connecting-ip':ip},body:credentials()}),env,fetcher);
    assert.equal(response.status,i<10?409:429);
  }
  assert.equal(calls,10);
});
test('disconnect clears both browser and upstream cookies',async()=>{
  const response=await handleSchools(request('disconnect',{method:'POST',body:'{}'}),env);assert.equal(response.status,200);assert.equal(cookies(response).length,2);for(const cookie of cookies(response))assert.match(cookie,/Max-Age=0/);
});
