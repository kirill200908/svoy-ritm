// Schools.by uses a Django login form. No password is stored or logged.
// The saved upstream session is sealed with a runtime-only AES-GCM key.
const SESSION_COOKIE = '__Secure-rhythm-school';
const BROWSER_COOKIE = '__Secure-rhythm-browser';
const LOGIN_URL = 'https://schools.by/login';
const MAX_HTML = 1500000;
const MAX_SESSION_AGE = 7 * 24 * 3600;
const MAX_BROWSER_AGE = 30 * 24 * 3600;
const loginAttempts = new Map();
const networkAttempts = new Map();
export class SchoolsError extends Error {
  constructor(code, message, status = 502) { super(message); this.code = code; this.status = status; }
}
const error = (code, message, status) => { throw new SchoolsError(code, message, status); };
const json = (body, status = 200, extra = {}) => {
  const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store, private', 'X-Content-Type-Options': 'nosniff' });
  const pairs = extra instanceof Headers ? extra.entries() : Object.entries(extra);
  for (const [name, value] of pairs) if (!(extra instanceof Headers) || name.toLowerCase() !== 'set-cookie') headers.append(name, value);
  if (extra instanceof Headers) {
    const cookies = typeof extra.getSetCookie === 'function' ? extra.getSetCookie() : (extra.get('set-cookie') || '').split(/,(?=\s*__Secure-rhythm-)/).filter(Boolean);
    for (const cookie of cookies) headers.append('Set-Cookie', cookie);
  }
  return new Response(JSON.stringify(body), { status, headers });
};
const encode64 = (bytes) => btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
const decode64 = (value) => Uint8Array.from(atob(value.replaceAll('-', '+').replaceAll('_', '/')), c => c.charCodeAt(0));
async function sessionKey(secret) {
  let bytes;
  try { bytes = decode64(secret); } catch { error('configuration', 'Подключение дневника ещё не настроено.', 503); }
  if (bytes.length !== 32) error('configuration', 'Подключение дневника ещё не настроено.', 503);
  return crypto.subtle.importKey('raw', bytes, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
export async function sealSession(data, secret, audience) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(audience) }, await sessionKey(secret), new TextEncoder().encode(JSON.stringify(data)));
  return encode64(iv) + '.' + encode64(new Uint8Array(cipher));
}
async function openSealed(token, secret, audience) {
  try {
    if (!token || token.length > 3500) return null;
    const parts = token.split('.'); if (parts.length !== 2) return null;
    const [iv, cipher] = parts; if (decode64(iv).length !== 12) return null;
    const bytes = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: decode64(iv), additionalData: new TextEncoder().encode(audience) }, await sessionKey(secret), decode64(cipher));
    const value = JSON.parse(new TextDecoder().decode(bytes));
    return value && typeof value.expires === 'number' && value.expires > Date.now() ? value : null;
  } catch { return null; }
}
export async function openSession(token, secret, audience) {
  const value = await openSealed(token, secret, audience);
  return value?.jar && typeof value.jar === 'object' && !Array.isArray(value.jar) ? value : null;
}
export async function openBrowserSession(token, secret, origin) {
  const value = await openSealed(token, secret, origin + '|browser-identity-v1');
  return value?.type === 'browser' && /^[a-f0-9]{64}$/.test(value.id || '') ? value : null;
}
function cookieHeader(token, age = MAX_SESSION_AGE) { return `${SESSION_COOKIE}=${token}; Path=/api/schools; Max-Age=${age}; HttpOnly; Secure; SameSite=Strict`; }
function browserCookieHeader(token, age = MAX_BROWSER_AGE) { return `${BROWSER_COOKIE}=${token}; Path=/api/schools; Max-Age=${age}; HttpOnly; Secure; SameSite=Strict`; }
function requestCookie(request, name) { return (request.headers.get('cookie') || '').split(';').map(v => v.trim()).find(v => v.startsWith(name + '='))?.slice(name.length + 1); }
function requestToken(request) { return requestCookie(request, SESSION_COOKIE); }
async function newBrowserSession(secret, origin) {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const id = Array.from(bytes).map(n => n.toString(16).padStart(2, '0')).join('');
  const browser = { type: 'browser', id, expires: Date.now() + MAX_BROWSER_AGE * 1000 };
  return { browser, token: await sealSession(browser, secret, origin + '|browser-identity-v1') };
}
async function checkLoginRate(request, browserId) {
  const now = Date.now(); const previous = loginAttempts.get(browserId) || 0;
  if (now - previous < 10000) error('too_many_attempts', 'Подожди 10 секунд перед следующей попыткой.', 429);
  const network = await fingerprint('login-rate|' + (request.headers.get('cf-connecting-ip') || 'unknown-network'));
  let bucket = networkAttempts.get(network);
  if (!bucket || now >= bucket.until) bucket = { count: 0, until: now + 10 * 60 * 1000 };
  if (bucket.count >= 10) error('too_many_attempts', 'Слишком много попыток входа с этой сети. Попробуй через 10 минут.', 429);
  loginAttempts.set(browserId, now); bucket.count++; networkAttempts.set(network, bucket);
  if (loginAttempts.size > 2000) loginAttempts.delete(loginAttempts.keys().next().value);
  if (networkAttempts.size > 2000) networkAttempts.delete(networkAttempts.keys().next().value);
}
function updateJar(headers, jar) {
  const values = typeof headers.getSetCookie === 'function' ? headers.getSetCookie() : (headers.get('set-cookie') || '').split(/,(?=\s*[\w-]+=)/);
  for (const value of values) {
    const match = value.trim().match(/^([A-Za-z0-9_-]+)=([^;\r\n]*)/);
    if (match && ['csrftoken', 'sessionid', 'slc_cookie'].includes(match[1])) jar[match[1]] = match[2];
  }
}
export function decodeEntities(value = '') {
  const named = { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' };
  return value.replace(/&(#x[\da-f]+|#\d+|amp|quot|apos|lt|gt|nbsp);/gi, (_, key) => {
    if (key[0] !== '#') return named[key.toLowerCase()] || '';
    const code = key[1].toLowerCase() === 'x' ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
    return code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : '';
  });
}
function attrs(value) {
  const result = {};
  for (const match of value.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g)) result[match[1].toLowerCase()] = decodeEntities(match[2] ?? match[3] ?? match[4] ?? '');
  return result;
}
// A bounded, non-executing HTML tree. Script, style and comments are ignored.
export function parseHtml(html) {
  const root = { tag: 'root', attrs: {}, children: [] }; const stack = [root];
  const source = html.replace(/<!--[\s\S]*?-->/g, '').replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, '');
  const voidTags = new Set(['br', 'hr', 'img', 'input', 'meta', 'link', 'area', 'base', 'wbr', 'source', 'embed']);
  let nodes = 0;
  for (const match of source.matchAll(/<\/([\w:-]+)\s*>|<([\w:-]+)\b((?:[^>"']|"[^"]*"|'[^']*')*)>|([^<]+)/g)) {
    if (++nodes > 80000) error('layout_changed', 'Страница дневника слишком большая для обработки.');
    if (match[1]) { const tag = match[1].toLowerCase(); for (let i = stack.length - 1; i > 0; i--) if (stack[i].tag === tag) { stack.length = i; break; } }
    else if (match[2]) {
      const tag = match[2].toLowerCase();
      const node = { tag, attrs: attrs(match[3]), children: [] }; stack[stack.length - 1].children.push(node);
      if (!voidTags.has(tag) && !match[3].trim().endsWith('/')) { if (stack.length >= 150) error('layout_changed', 'Не удалось распознать страницу дневника.'); stack.push(node); }
    } else stack[stack.length - 1].children.push(decodeEntities(match[4] || ''));
  }
  return root;
}
const content = (node) => typeof node === 'string' ? node : node.children.map(content).join(' ');
const normalized = (node) => content(node).replace(/\s+/g, ' ').trim();
function findAll(node, predicate) { const result = []; for (const child of node.children || []) if (typeof child !== 'string') { if (predicate(child)) result.push(child); result.push(...findAll(child, predicate)); } return result; }
const hasClass = (node, cls) => (node.attrs.class || '').split(/\s+/).includes(cls);
const iso = (date) => date.toISOString().slice(0, 10);
const validDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && Number.isFinite(Date.parse(value + 'T12:00:00Z')) && iso(new Date(value + 'T12:00:00Z')) === value;
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Minsk', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const shift = (value, days) => { const date = new Date(value + 'T12:00:00Z'); date.setUTCDate(date.getUTCDate() + days); return iso(date); };
const months = { января: 1, февраля: 2, марта: 3, апреля: 4, мая: 5, июня: 6, июля: 7, августа: 8, сентября: 9, октября: 10, ноября: 11, декабря: 12 };
function dateOfDay(node, week, index) {
  const raw = node.attrs['data-date'] || node.attrs['data-day'] || '';
  if (validDate(raw)) return raw;
  const header = findAll(node, n => /^h[1-6]$/.test(n.tag) || hasClass(n, 'db_day_header') || hasClass(n, 'db_date') || hasClass(n, 'date'));
  const text = header.map(normalized).join(' ') || normalized(node).slice(0, 120);
  const full = text.match(/\b(\d{2})\.(\d{2})\.(\d{4})\b/);
  if (full) { const key = `${full[3]}-${full[2]}-${full[1]}`; if (validDate(key)) return key; }
  const named = text.toLowerCase().match(/\b(\d{1,2})\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)(?:\s+(20\d{2}))?/);
  if (named) {
    const month = months[named[2]]; let year = named[3] ? Number(named[3]) : Number((week || today()).slice(0, 4));
    if (!named[3] && week && Number(week.slice(5, 7)) === 12 && month === 1) year++;
    const key = `${year}-${String(month).padStart(2, '0')}-${named[1].padStart(2, '0')}`; if (validDate(key)) return key;
  }
  const weekdays = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'];
  const weekday = weekdays.findIndex(name => text.toLowerCase().includes(name));
  if (validDate(week) && weekday >= 0) return shift(week, weekday);
  return null;
}
async function fingerprint(value) { const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)); return Array.from(new Uint8Array(bytes)).slice(0, 16).map(n => n.toString(16).padStart(2, '0')).join(''); }
export async function parseDiary(html, url, pupilId) {
  const root = parseHtml(html);
  if (findAll(root, n => n.tag === 'input' && (n.attrs.name === 'password' || n.attrs.type === 'password')).length) error('session_expired', 'Вход в Schools.by истёк. Введи логин и пароль заново.', 401);
  const week = url.match(/\/week\/(\d{4}-\d{2}-\d{2})/)?.[1];
  const groups = findAll(root, n => hasClass(n, 'db_days')).map(n => findAll(n, day => hasClass(day, 'db_day'))).filter(days => days.length > 0 && days.length <= 7);
  groups.sort((a, b) => b.reduce((s, d) => s + findAll(d, n => hasClass(n, 'mark_box')).length, 0) - a.reduce((s, d) => s + findAll(d, n => hasClass(n, 'mark_box')).length, 0));
  const dayNodes = groups[0] || findAll(root, n => hasClass(n, 'db_day'));
  if (!dayNodes.length) {
    if (/g-recaptcha|h-captcha|challenge-platform|cf-chl-/i.test(html)) error('verification_required', 'Schools.by требует проверку при открытии дневника. Войди на самом Schools.by; автоматическое чтение сейчас недоступно.', 409);
    const text = normalized(root);
    if (/доступ\s+запрещ[её]н|нет\s+прав\s+доступа|access\s+denied/i.test(text)) error('upstream_blocked', 'Schools.by не разрешил открыть этот дневник. Проверь, что он доступен твоей учётной записи на самом Schools.by.', 403);
    if (findAll(root, n => n.tag === 'form').length && /согласи[ея]\s+на\s+обработку\s+персональных/i.test(text)) error('agreement_required', 'Schools.by просит подтвердить согласие. Открой сам Schools.by и проверь сообщение, затем попробуй подключиться снова.', 409);
    // Only structural counts are returned: no page text, pupil ID, URLs or cookies.
    const variant = new URL(url).pathname.startsWith('/m/') ? 'M' : 'D';
    const counts = ['table', 'form'].map(tag => findAll(root, n => n.tag === tag).length);
    const marks = findAll(root, n => hasClass(n, 'mark_box')).length;
    const lessons = findAll(root, n => n.tag === 'td' && hasClass(n, 'lesson')).length;
    error('layout_changed', `Не удалось распознать таблицу Schools.by. Оценки не изменены. Код проверки: ${variant}-T${counts[0]}-F${counts[1]}-M${marks}-L${lessons}.`);
  }
  const grades = []; const dates = new Set();
  // Use one table when the page renders mobile and desktop copies.
  for (let d = 0; d < dayNodes.length; d++) {
    const day = dayNodes[d]; const date = dateOfDay(day, week, d % 7); if (!date || date > today()) continue; dates.add(date);
    const rows = findAll(day, n => n.tag === 'tr');
    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
      const row = rows[rowIndex]; const lesson = findAll(row, n => n.tag === 'td' && hasClass(n, 'lesson'))[0];
      const box = findAll(row, n => hasClass(n, 'mark_box'))[0]; if (!lesson || !box) continue;
      const subject = normalized(lesson).replace(/^\d+[.)]?\s*/, '').trim(); const raw = normalized(box);
      if (!subject || !/^(?:10|[1-9])(?:\s*[/,]\s*(?:10|[1-9]))*$/.test(raw)) continue;
      const values = raw.split(/\s*[/,]\s*/).map(Number);
      for (let m = 0; m < values.length; m++) {
        const lessonPosition = normalized(lesson).match(/^\d+/)?.[0] || String(rowIndex);
        const id = await fingerprint(`${pupilId}|${date}|${subject.toLowerCase()}|${lessonPosition}|${m}`);
        grades.push({ id, date, subject: subject.slice(0, 160), value: values[m] });
      }
    }
  }
  if (!dates.size) error('layout_changed', 'Не удалось определить даты оценок. Баллы не изменены.');
  return { grades: Array.from(new Map(grades.map(g => [g.id, g])).values()), dates: [...dates].sort() };
}
function configuration(env) {
  if (!env.SCHOOLS_SESSION_KEY || env.SCHOOLS_HOST !== 'lyceum.schools.by' || !/^\d{1,12}$/.test(env.SCHOOLS_PUPIL_ID || '')) error('configuration', 'Подключение дневника ещё не настроено.', 503);
  return { host: env.SCHOOLS_HOST, pupilId: env.SCHOOLS_PUPIL_ID };
}
async function upstream(url, jar, init = {}, fetcher = fetch) {
  const target = new URL(url);
  if (target.protocol !== 'https:' || !['schools.by', 'lyceum.schools.by'].includes(target.hostname)) error('redirect_blocked', 'Schools.by вернул неподдерживаемый адрес входа.');
  let response;
  try { response = await fetcher(url, { ...init, redirect: 'manual', signal: AbortSignal.timeout(10000), headers: { 'User-Agent': 'Mozilla/5.0 (compatible; SvoyRitm/1.0)', ...init.headers, Cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ') } }); }
  catch { error('upstream_unavailable', 'Schools.by сейчас не отвечает серверу. Попробуй подключить дневник позже. Пароль не сохранён.', 503); }
  updateJar(response.headers, jar);
  if ([301, 302, 303, 307, 308].includes(response.status)) { const location = response.headers.get('location'); if (!location) error('upstream_unavailable', 'Schools.by вернул пустой адрес перенаправления.'); return { redirect: new URL(location, url).href, status: response.status }; }
  if (response.status === 403 || response.status === 429) error('upstream_blocked', 'Schools.by ограничил автоматический доступ. Попробуй позже или войди в дневник напрямую.', 503);
  if (!response.ok) error('upstream_unavailable', 'Schools.by временно не смог открыть дневник.', 503);
  const reader = response.body?.getReader(); const chunks = []; let size = 0;
  if (reader) { while (true) { const { value, done } = await reader.read(); if (done) break; size += value.length; if (size > MAX_HTML) { await reader.cancel(); error('layout_changed', 'Ответ дневника слишком большой.'); } chunks.push(value); } }
  const bytes = new Uint8Array(size); let offset = 0; for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return { html: new TextDecoder().decode(bytes), url };
}
async function follow(url, jar, fetcher) {
  for (let i = 0; i < 5; i++) { const result = await upstream(url, jar, {}, fetcher); if (!result.redirect) return result; url = result.redirect; }
  error('redirect_blocked', 'Schools.by зациклил вход. Попробуй подключиться заново.');
}
function diaryLinks(root, pageUrl, config) {
  const prefix = `/pupil/${config.pupilId}/dnevnik`;
  return findAll(root, n => n.tag === 'a' && n.attrs.href).flatMap(node => {
    try {
      const link = new URL(node.attrs.href, pageUrl);
      const suffix = link.pathname.slice(prefix.length).replace(/\/$/, '');
      if (link.protocol !== 'https:' || link.host !== config.host || link.username || link.password || !link.pathname.startsWith(prefix) || !/^(?:\/quarter\/\d+)?(?:\/week\/\d{4}-\d{2}-\d{2})?$/.test(suffix)) return [];
      link.hash = ''; link.search = '';
      return [link];
    } catch { return []; }
  });
}
async function readDiary(config, jar, fetcher) {
  let page = await follow(`https://${config.host}/pupil/${config.pupilId}/dnevnik`, jar, fetcher);
  // Some accounts first receive a profile/quarter page rather than the week.
  // Follow only actual, same-school links for the configured pupil.
  const visited = new Set([page.url]);
  for (let hop = 0; hop < 2; hop++) {
    const root = parseHtml(page.html);
    if (findAll(root, n => hasClass(n, 'db_day') || (n.tag === 'input' && (n.attrs.name === 'password' || n.attrs.type === 'password'))).length) break;
    if (/g-recaptcha|h-captcha|challenge-platform|cf-chl-/i.test(page.html) || /доступ\s+запрещ[её]н|нет\s+прав\s+доступа|access\s+denied|согласи[ея]\s+на\s+обработку\s+персональных/i.test(normalized(root))) break;
    const links = diaryLinks(root, page.url, config).filter(link => !visited.has(link.href));
    const rank = link => {
      const week = link.pathname.match(/\/week\/(\d{4}-\d{2}-\d{2})/)?.[1];
      return week && week <= today() ? '2' + week : week ? '0' + week : '1' + link.pathname;
    };
    links.sort((a, b) => rank(b).localeCompare(rank(a)));
    if (!links.length) break;
    visited.add(links[0].href);
    page = await follow(links[0].href, jar, fetcher);
    visited.add(page.url);
  }
  const parsed = await parseDiary(page.html, page.url, config.pupilId);
  // Read one previous week as well, if its actual link exists on the current page.
  const root = parseHtml(page.html); const currentWeek = page.url.match(/\/week\/(\d{4}-\d{2}-\d{2})/)?.[1];
  const previous = diaryLinks(root, page.url, config).filter(u => {
    const week = u.pathname.match(/\/week\/(\d{4}-\d{2}-\d{2})/)?.[1];
    return week && week < (currentWeek || today());
  }).sort((a, b) => b.pathname.match(/\/week\/(\d{4}-\d{2}-\d{2})/)[1].localeCompare(a.pathname.match(/\/week\/(\d{4}-\d{2}-\d{2})/)[1]))[0];
  if (previous) {
    const old = await follow(previous.href, jar, fetcher); const extra = await parseDiary(old.html, old.url, config.pupilId);
    parsed.grades.push(...extra.grades); parsed.dates.push(...extra.dates);
  }
  return { grades: Array.from(new Map(parsed.grades.map(g => [g.id, g])).values()).sort((a, b) => b.date.localeCompare(a.date)), checkedDates: [...new Set(parsed.dates)].sort(), checkedAt: new Date().toISOString() };
}
async function login(username, password, config, fetcher) {
  const jar = {}; const page = await follow(LOGIN_URL, jar, fetcher);
  if (/g-recaptcha|h-captcha|name=["']captcha/i.test(page.html)) error('verification_required', 'Schools.by требует проверку при входе. Автоматическое подключение сейчас недоступно.', 409);
  const root = parseHtml(page.html); const token = findAll(root, n => n.tag === 'input' && n.attrs.name === 'csrfmiddlewaretoken')[0]?.attrs.value;
  if (!token) error('layout_changed', 'Не удалось распознать форму входа Schools.by. Пароль не отправлен.');
  const response = await upstream(LOGIN_URL, jar, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Referer: LOGIN_URL, Origin: 'https://schools.by' }, body: new URLSearchParams({ username, password, csrfmiddlewaretoken: token, '|123': '|123' }).toString() }, fetcher);
  if (!jar.sessionid) error('invalid_credentials', 'Schools.by не подтвердил вход. Проверь логин и пароль.', 401);
  // Reading the configured pupil's diary is the authority check, not the redirect alone.
  const result = await readDiary(config, jar, fetcher);
  return { jar, result };
}
export async function handleSchools(request, env, fetcher = fetch) {
  try {
    const url = new URL(request.url);
    if (request.headers.get('sec-fetch-site') === 'cross-site') return json({ error: 'origin_rejected', message: 'Открой дневник на странице «Своего ритма».' }, 403);
    const origin = request.headers.get('origin');
    if (origin && origin !== url.origin) return json({ error: 'origin_rejected', message: 'Обнови страницу и попробуй ещё раз.' }, 403);
    const config = configuration(env);
    let browser = await openBrowserSession(requestCookie(request, BROWSER_COOKIE), env.SCHOOLS_SESSION_KEY, url.origin);
    if (request.method === 'GET' && url.pathname === '/api/schools/status') {
      const headers = new Headers();
      if (!browser) { const created = await newBrowserSession(env.SCHOOLS_SESSION_KEY, url.origin); browser = created.browser; headers.append('Set-Cookie', browserCookieHeader(created.token)); }
      const audience = url.origin + '|browser|' + browser.id;
      let saved = await openSession(requestToken(request), env.SCHOOLS_SESSION_KEY, audience);
      // Preserve existing connections created before browser-based login, when their old owner is still signed in.
      const legacyUser = request.headers.get('oai-authenticated-user-id');
      if (!saved && legacyUser) {
        saved = await openSession(requestToken(request), env.SCHOOLS_SESSION_KEY, url.origin + '|' + legacyUser);
        if (saved) headers.append('Set-Cookie', cookieHeader(await sealSession(saved, env.SCHOOLS_SESSION_KEY, audience), Math.max(0, Math.floor((saved.expires - Date.now()) / 1000))));
      }
      return json({ connected: !!saved, school: config.host, expiresAt: saved ? new Date(saved.expires).toISOString() : null }, 200, headers);
    }
    if (request.method !== 'POST') return json({ error: 'method_not_allowed', message: 'Этот способ запроса не поддерживается.' }, 405, { Allow: 'POST' });
    if (request.headers.get('origin') !== url.origin) return json({ error: 'origin_rejected', message: 'Обнови страницу и попробуй ещё раз.' }, 403);
    if (url.pathname === '/api/schools/disconnect') {
      const headers = new Headers(); headers.append('Set-Cookie', cookieHeader('', 0)); headers.append('Set-Cookie', browserCookieHeader('', 0));
      return json({ connected: false }, 200, headers);
    }
    if (!browser) return json({ error: 'browser_session_missing', message: 'Обнови страницу и разреши cookie для этого сайта, чтобы войти в дневник.' }, 409);
    const audience = url.origin + '|browser|' + browser.id;
    if (url.pathname === '/api/schools/connect') {
      if (!request.headers.get('content-type')?.startsWith('application/json')) return json({ error: 'invalid_request', message: 'Не удалось прочитать форму входа.' }, 400);
      const text = await request.text(); if (text.length > 4096) return json({ error: 'invalid_request', message: 'Данные входа слишком длинные.' }, 400);
      let body; try { body = JSON.parse(text); } catch { return json({ error: 'invalid_request', message: 'Не удалось прочитать форму входа.' }, 400); }
      if (typeof body.username !== 'string' || !body.username.trim() || body.username.length > 200 || typeof body.password !== 'string' || !body.password || body.password.length > 500) return json({ error: 'invalid_request', message: 'Введи логин и пароль дневника.' }, 400);
      await checkLoginRate(request, browser.id);
      const { jar, result } = await login(body.username.trim(), body.password, config, fetcher); body.password = '';
      const token = await sealSession({ jar, expires: Date.now() + MAX_SESSION_AGE * 1000 }, env.SCHOOLS_SESSION_KEY, audience);
      if (token.length > 3500) error('session_invalid', 'Не удалось сохранить вход в дневник.');
      return json({ connected: true, ...result }, 200, { 'Set-Cookie': cookieHeader(token) });
    }
    if (url.pathname === '/api/schools/grades') {
      const saved = await openSession(requestToken(request), env.SCHOOLS_SESSION_KEY, audience);
      if (!saved) return json({ error: 'session_expired', message: 'Введи логин и пароль, чтобы подключить дневник.' }, 401, { 'Set-Cookie': cookieHeader('', 0) });
      const result = await readDiary(config, saved.jar, fetcher);
      const token = await sealSession(saved, env.SCHOOLS_SESSION_KEY, audience);
      return json({ connected: true, ...result }, 200, { 'Set-Cookie': cookieHeader(token, Math.max(0, Math.floor((saved.expires - Date.now()) / 1000))) });
    }
    return json({ error: 'not_found', message: 'Такой страницы нет.' }, 404);
  } catch (failure) {
    if (failure instanceof SchoolsError) return json({ error: failure.code, message: failure.message }, failure.status, failure.code === 'session_expired' ? { 'Set-Cookie': cookieHeader('', 0) } : {});
    return json({ error: 'server_error', message: 'Не удалось выполнить запрос. Попробуй позже.' }, 500);
  }
}
