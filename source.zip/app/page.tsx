"use client";
import { useEffect, useRef, useState } from "react";
import { ArrowDownToLine, ArrowRight, ArrowUpRight, Atom, BookOpen, Check, ChevronLeft, ChevronRight, Code2, Compass, Flag, Heart, History, LayoutDashboard, ListChecks, MoreHorizontal, Plus, Settings2, ShieldCheck, Sparkles, Sprout, Target, Trash2, Trophy, Upload, X } from "lucide-react";
import { INITIAL_SETTINGS, dateKey, shiftDate, totalPoints, progress, validateBackup, type Achievement, type Settings, type Store } from "../lib/day-model";
import SchoolConnection from './school-connection';
import { mergeSchoolGrades } from '../lib/school-import';

const STORAGE_KEY = "own-rhythm:v1";
const ICONS: Record<string, typeof Atom> = { math: BookOpen, physics: Atom, subject: Trophy, codeforces: Code2, ejudge: ListChecks, contest: Flag };
const EMPTY: Store = { version: 1, settings: INITIAL_SETTINGS, achievements: [], notes: {}, targets: {} };
type Tab = "day" | "history" | "values" | "school";
type Draft = { kind: string; title: string; count: number };
function dayLabel(date: string, options: Intl.DateTimeFormatOptions = { day: "numeric", month: "long" }) { return new Intl.DateTimeFormat("ru-RU", options).format(new Date(date + "T12:00:00")); }
function plural(n: number, words: string[]) { const k = Math.abs(n) % 100; return words[k > 10 && k < 20 ? 2 : k % 10 === 1 ? 0 : k % 10 > 1 && k % 10 < 5 ? 1 : 2]; }
function weekDates(date: string) { const weekday = new Date(date + "T12:00:00").getDay(); const monday = shiftDate(date, -(weekday === 0 ? 6 : weekday - 1)); return Array.from({ length: 7 }, (_, i) => shiftDate(monday, i)); }

export default function Home() {
  const [store, setStore] = useState<Store>(EMPTY);
  const [ready, setReady] = useState(false);
  const [date, setDate] = useState("");
  const [today, setToday] = useState("");
  const [tab, setTab] = useState<Tab>("day");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [toast, setToast] = useState("");
  const [storageError, setStorageError] = useState("");
  const [targetDialog, setTargetDialog] = useState(false);
  const [targetInput, setTargetInput] = useState(60);
  const [settingsDraft, setSettingsDraft] = useState<Settings>(INITIAL_SETTINGS);
  const [backup, setBackup] = useState<Store | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const firstField = useRef<HTMLInputElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const undoRef = useRef<Achievement | null>(null);
  useEffect(() => {
    const current = dateKey(); setToday(current); setDate(current);
    try { const raw = localStorage.getItem(STORAGE_KEY); if (raw) { const saved = validateBackup(JSON.parse(raw)); setStore(saved); setSettingsDraft(saved.settings); } }
    catch { setStorageError("Не удалось прочитать сохранённые данные. Можно восстановить их из резервной копии. Попробуй импорт или перезагрузку."); }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready || storageError) return;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(store)); }
    catch { setStorageError("Браузер не разрешил сохранение. Экспортируй данные, чтобы не потерять записи после закрытия страницы."); }
  }, [store, ready, storageError]);
  useEffect(() => { if (!toast) return; const id = setTimeout(() => setToast(""), 5500); return () => clearTimeout(id); }, [toast]);
  const modalOpen = !!draft || targetDialog || !!backup;
  useEffect(() => {
    if (!modalOpen) return;
    previousFocus.current = document.activeElement as HTMLElement;
    const overflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    const handle = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setDraft(null); setTargetDialog(false); setBackup(null); }
      if (event.key === "Tab") {
        const els = Array.from(document.querySelectorAll<HTMLElement>('[role="dialog"] button, [role="dialog"] input, [role="dialog"] select'));
        const first = els[0], last = els[els.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", handle);
    const timer = setTimeout(() => (firstField.current ?? document.querySelector<HTMLElement>('[role="dialog"] input, [role="dialog"] button'))?.focus(), 30);
    return () => { clearTimeout(timer); document.body.style.overflow = overflow; document.removeEventListener("keydown", handle); previousFocus.current?.focus(); };
  }, [modalOpen]);

  const daily = store.achievements.filter((a) => a.date === date);
  const total = totalPoints(daily);
  const target = store.targets[date] ?? store.settings.target;
  const percentage = progress(total, target);
  const week = date ? weekDates(date) : [];
  const weekItems = store.achievements.filter((a) => week.includes(a.date));
  const weekly = totalPoints(weekItems);
  const activeDays = new Set(weekItems.map((a) => a.date)).size;
  const tasks = daily.filter((a) => ["codeforces", "ejudge"].includes(a.kind)).reduce((s, a) => s + a.count, 0);
  const grades = daily.filter((a) => ["math", "physics", "subject"].includes(a.kind)).reduce((s, a) => s + a.count, 0);
  const historyDates = Array.from(new Set([...store.achievements.map((a) => a.date), ...Object.keys(store.notes).filter((key) => store.notes[key].trim())])).sort().reverse();
  const selectedKind = draft ? store.settings.kinds.find((kind) => kind.id === draft.kind) : null;
  const oldEntry = editing ? store.achievements.find((a) => a.id === editing) : null;
  const draftPoints = oldEntry && draft && oldEntry.kind === draft.kind ? oldEntry.points : selectedKind?.points ?? 0;
  const notify = (message: string) => setToast(message);
  function openEntry(kind = "codeforces", item?: Achievement) { setEditing(item?.id ?? null); setDraft({ kind: item?.kind ?? kind, title: item?.title ?? "", count: item?.count ?? 1 }); }
  function saveEntry(event: React.FormEvent) {
    event.preventDefault(); if (!draft || !selectedKind || !Number.isInteger(draft.count) || draft.count < 1 || draft.count > 100) return;
    const item: Achievement = { id: editing ?? crypto.randomUUID(), date, kind: draft.kind, label: selectedKind.label, title: draft.title.trim(), count: draft.count, points: draftPoints, createdAt: oldEntry?.createdAt ?? new Date().toISOString(), ...(oldEntry?.sourceId ? { sourceId: oldEntry.sourceId } : {}) };
    setStore((s) => ({ ...s, targets: { ...s.targets, [date]: target }, achievements: oldEntry ? s.achievements.map((a) => a.id === editing ? item : a) : [...s.achievements, item] }));
    setDraft(null); notify(oldEntry ? "Запись обновлена" : "Результат добавлен. Ещё один шаг вперёд.");
  }
  function remove(item: Achievement) { undoRef.current = item; setStore((s) => ({ ...s, achievements: s.achievements.filter((a) => a.id !== item.id), ...(item.sourceId ? { ignoredSchoolIds: [...new Set([...(s.ignoredSchoolIds || []), item.sourceId])] } : {}) })); notify("Запись удалена"); }
  function undo() { const item = undoRef.current; if (!item) return; setStore((s) => ({ ...s, achievements: [...s.achievements.filter((a) => a.id !== item.id), item], ...(item.sourceId ? { ignoredSchoolIds: (s.ignoredSchoolIds || []).filter(id => id !== item.sourceId) } : {}) })); undoRef.current = null; setToast("Удаление отменено"); }
  function exportData() {
    const url = URL.createObjectURL(new Blob([JSON.stringify(store, null, 2)], { type: "application/json" }));
    const link = document.createElement("a"); link.href = url; link.download = `svoy-ritm-${today}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 2000); notify("Резервная копия скачана");
  }
  async function importData(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]; if (!file) return;
    try { if (file.size > 5_000_000) throw new Error(); setBackup(validateBackup(JSON.parse(await file.text()))); }
    catch { notify("Этот файл не похож на резервную копию «Своего ритма»"); }
    event.target.value = "";
  }
  function changeTab(next: Tab) { setTab(next); if (next === "values") setSettingsDraft(structuredClone(store.settings)); }
  if (!ready) return <main className="loading"><Compass size={38} /><p>Находим твой ритм…</p></main>;

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={(e) => { e.preventDefault(); changeTab("day"); }}><span className="brand-symbol"><Compass size={24} /></span><span>свой ритм<span className="brand-dot">.</span></span></a>
      <div className="sidebar-kicker">ЛИЧНОЕ ПРОСТРАНСТВО</div>
      <nav aria-label="Основная навигация">{([{ id: "day", label: "Мой день", Icon: LayoutDashboard }, { id: "history", label: "История", Icon: History }, { id: "school", label: "Дневник", Icon: BookOpen }, { id: "values", label: "Мои ценности", Icon: Settings2 }] as const).map(({ id, label, Icon }) => <button key={id} className={tab === id ? "nav-item active" : "nav-item"} onClick={() => changeTab(id)}><Icon size={19} />{label}<span className="nav-dot" /></button>)}</nav>
      <div className="sidebar-note"><span className="sprout"><Sprout size={24} /></span><h3>У каждого свой темп.</h3><p>Замечай то, что получилось. Даже маленький шаг считается.</p><span className="note-doodle" aria-hidden="true">↗</span></div>
      <div className="sidebar-bottom"><span className="avatar">Я</span><div><strong>Мой дневник</strong><span>Пространство для роста</span></div><Heart size={16} /></div>
    </aside>
    <div className="main-shell">
      <header className="topbar"><span className="breadcrumb">Моё пространство <span>/</span> <strong>{tab === "day" ? "Мой день" : tab === "history" ? "История" : tab === "school" ? "Дневник" : "Мои ценности"}</strong></span><span className={storageError ? "save-state error" : "save-state"}><ShieldCheck size={15} />{storageError ? "Нужно сохранить копию" : "Сохраняется в этом браузере"}</span></header>
      <main className="content">
        <SchoolConnection active={tab === 'school'} onGrades={grades => setStore(s => mergeSchoolGrades(s, grades))} />
        {storageError && <div role="alert" className="storage-alert">{storageError}<button onClick={exportData}>Скачать копию</button><button onClick={() => fileRef.current?.click()}>Восстановить</button></div>}
        {tab === "day" && <>
          <section className="page-heading"><div><div className="eyebrow"><span />ДЕНЬ ЗА ДНЁМ, БЛИЖЕ К СВОЕМУ</div><h1>Твой день. Твои ориентиры.</h1><p>Здесь считается то, что важно именно тебе.</p></div><div className="date-picker"><button aria-label="Предыдущий день" onClick={() => setDate(shiftDate(date, -1))}><ChevronLeft size={17} /></button><label><span>{date === today ? "Сегодня, " : ""}{dayLabel(date)}</span><input aria-label="Выбрать день" type="date" value={date} max={today} onChange={(e) => { if (e.target.value && e.target.value <= today) setDate(e.target.value); }} /></label><button aria-label="Следующий день" disabled={date >= today} onClick={() => setDate(shiftDate(date, 1))}><ChevronRight size={17} /></button></div></section>
          <div className="overview-grid">
            <section className="score-card"><div className="card-top"><span><span className="little-dot" />ТВОЙ ПРОГРЕСС ЗА ДЕНЬ</span><button aria-label="Настроить ориентир дня" onClick={() => { setTargetInput(target); setTargetDialog(true); }}><MoreHorizontal size={23} /></button></div><div className="score-main"><div className="score-number"><strong>{total}</strong><span>баллов за важное</span></div><div className="score-ring" role="img" aria-label={`${percentage}% дневного ориентира`}><svg viewBox="0 0 100 100"><circle className="ring-track" cx="50" cy="50" r="43" /><circle className="ring-fill" cx="50" cy="50" r="43" strokeDasharray={`${percentage * 2.702} 270.2`} /></svg><span>{percentage}<small>%</small></span></div></div><div className="score-caption"><span>{total >= target ? "Дневной ориентир достигнут" : `Твой ориентир — ${target} баллов`}</span><button onClick={() => { setTargetInput(target); setTargetDialog(true); }}>Изменить <ArrowUpRight size={13} /></button></div><div className="score-divider" /><p className="score-message"><Sparkles size={17} />{!daily.length ? "Первый шаг может быть совсем небольшим." : total >= target ? "Есть за что себя поблагодарить. Можно выдохнуть." : "Каждый результат приближает к тому, что важно."}</p></section>
            <section className="panel week-card"><div className="section-head"><h2>Неделя в твоём ритме</h2><span className="week-range">{dayLabel(week[0], { day: "numeric" })}–{dayLabel(week[6], { day: "numeric", month: "short" })}</span></div><div className="week-bars">{week.map((key, i) => { const points = totalPoints(store.achievements.filter((a) => a.date === key)); const pct = progress(points, store.targets[key] ?? store.settings.target); return <button key={key} className={`week-column ${key === date ? "selected" : ""} ${key > today ? "future" : ""}`} disabled={key > today} onClick={() => setDate(key)} aria-label={`${dayLabel(key)}: ${points} баллов`}><span className="bar-value">{points || "—"}</span><span className="bar-track"><span style={{ height: `${pct}%` }} /></span><span className="bar-day">{["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"][i]}{key === today && <i />}</span></button>; })}</div><div className="week-footer"><span><i className="legend-dot" />Доля дневного ориентира</span><strong>{weekly} <small>баллов</small></strong></div></section>
          </div>
          <div className="mini-stats"><div><span className="mini-icon lilac"><Code2 size={20} /></span><span><strong>{tasks}</strong><small>{plural(tasks, ["решённая задача", "решённые задачи", "решённых задач"])}</small></span></div><div><span className="mini-icon peach"><Trophy size={20} /></span><span><strong>{grades}</strong><small>{plural(grades, ["полученная десятка", "полученные десятки", "полученных десяток"])}</small></span></div><div><span className="mini-icon mint"><Sprout size={20} /></span><span><strong>{activeDays}<em> / 7</em></strong><small>{plural(activeDays, ["день с результатами на неделе", "дня с результатами на неделе", "дней с результатами на неделе"])}</small></span></div></div>
          <section className="quick-section"><div className="section-head"><div><h2>Что сегодня получилось?</h2><p>Выбери результат — он появится в дневнике.</p></div><button className="text-button" onClick={() => changeTab("values")}><Settings2 size={15} />Настроить баллы</button></div><div className="quick-grid">{store.settings.kinds.map((kind) => { const Icon = ICONS[kind.id] ?? Target; return <button key={kind.id} className={`quick-card ${kind.color}`} onClick={() => openEntry(kind.id)}><span className="quick-icon"><Icon size={22} /></span><span className="quick-label"><strong>{kind.label}</strong><span>{kind.hint}</span></span><span className="points-badge">+{kind.points}</span><span className="quick-plus"><Plus size={18} /></span></button>; })}</div></section>
          <div className="bottom-grid"><section className="panel results-card"><div className="section-head"><h2>Маленькие победы дня <span className="count-pill">{daily.length}</span></h2><button className="icon-button" aria-label="Добавить результат" onClick={() => openEntry()}><Plus size={19} /></button></div>{!daily.length ? <div className="empty-state"><span><Flag size={27} /></span><h3>Здесь будут твои результаты</h3><p>Решил задачу или получил десятку?<br />Запиши — такие вещи легко забыть.</p><button className="primary-button" onClick={() => openEntry()}><Plus size={16} />Добавить первый результат</button></div> : <div className="result-list">{[...daily].reverse().map((item) => { const kind = store.settings.kinds.find((k) => k.id === item.kind); const Icon = ICONS[item.kind] ?? Target; return <div className="result-row" key={item.id}><span className={`result-icon ${kind?.color ?? "mint"}`}><Icon size={19} /></span><button className="result-text" onClick={() => openEntry(item.kind, item)}><strong>{item.title || item.label}</strong><span>{item.label}{item.count > 1 ? ` × ${item.count}` : ""} · {dayLabel(date, { day: "numeric", month: "short" })}</span></button><span className="result-points">+{item.points * item.count}</span><button className="delete-button" aria-label={`Удалить: ${item.title || item.label}`} onClick={() => remove(item)}><Trash2 size={15} /></button></div>; })}</div>}</section><section className="panel reflection-card"><div className="section-head"><h2>Пара слов о дне</h2><span className="reflection-icon"><BookOpen size={18} /></span></div><p>Что получилось, что мешало, что хочется попробовать завтра?</p><label className="sr-only" htmlFor="daily-note">Заметка за {dayLabel(date)}</label><textarea id="daily-note" maxLength={5000} placeholder="Сегодня я доволен тем, что…" value={store.notes[date] ?? ""} onChange={(e) => setStore((s) => ({ ...s, notes: { ...s.notes, [date]: e.target.value } }))} /><div className="reflection-footer"><Check size={13} /><span>{storageError ? "Заметка пока не сохранена в браузере" : "Заметка сохраняется автоматически"}</span></div><div className="gentle-reminder"><span>☀</span><p>Отдых тоже нужен. День без баллов — это просто день без записанных результатов.</p></div></section></div>
          <footer className="page-footer"><Compass size={15} /><span>Важен твой путь. Баллы лишь помогают его замечать.</span><button onClick={exportData}><ArrowDownToLine size={14} />Скачать дневник</button></footer>
        </>}
        {tab === "history" && <><section className="page-heading"><div><div className="eyebrow"><span />ТВОЙ ПУТЬ В ЗАПИСЯХ</div><h1>Каждый шаг остаётся.</h1><p>Возвращайся к результатам и замечай свой прогресс.</p></div><button className="secondary-button" onClick={exportData}><ArrowDownToLine size={16} />Скачать дневник</button></section><div className="history-summary"><div><small>Всего баллов</small><strong>{totalPoints(store.achievements)}</strong></div><div><small>Записанных результатов</small><strong>{store.achievements.reduce((sum, a) => sum + a.count, 0)}</strong></div><div><small>Дней с записями</small><strong>{historyDates.length}</strong></div></div><section className="panel history-panel">{!historyDates.length ? <div className="empty-state"><span><History size={28} /></span><h3>История начинается с одного дня</h3><p>Добавь первый результат или заметку — и он появится здесь.</p><button className="primary-button" onClick={() => { setDate(today); changeTab("day"); }}>Перейти к сегодняшнему дню <ArrowRight size={15} /></button></div> : historyDates.map((key) => { const items = store.achievements.filter((a) => a.date === key); return <button className="history-row" key={key} onClick={() => { setDate(key); changeTab("day"); }}><span className="history-date"><strong>{dayLabel(key, { day: "numeric" })}</strong><small>{dayLabel(key, { month: "short" })}</small></span><span className="history-text"><strong>{dayLabel(key, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</strong><span>{items.length ? items.map((a) => a.title || a.label).join(" · ") : store.notes[key]}</span></span><span className="history-points">{totalPoints(items)}<small> баллов</small></span><ArrowUpRight size={19} /></button>; })}</section></>}
        {tab === "values" && <><section className="page-heading"><div><div className="eyebrow"><span />ПРАВИЛА ЗАДАЁШЬ ТЫ</div><h1>То, что важно тебе.</h1><p>Математика, физика и задачи. Настрой свой способ замечать прогресс.</p></div><span className="values-header-icon"><Target size={38} /></span></section><form ref={formRef} className="settings-grid" onSubmit={(e) => { e.preventDefault(); if (!formRef.current?.reportValidity()) return; setStore((s) => ({ ...s, settings: structuredClone(settingsDraft) })); notify("Твои приоритеты сохранены"); }}><section className="panel values-panel"><div className="section-head"><div><h2>Вес твоих результатов</h2><p>Больше баллов — больше значения для тебя.</p></div><Settings2 size={20} /></div>{settingsDraft.kinds.map((kind, index) => { const Icon = ICONS[kind.id] ?? Target; return <div className="value-row" key={kind.id}><span className={`result-icon ${kind.color}`}><Icon size={20} /></span><label htmlFor={`weight-${kind.id}`}><strong>{kind.label}</strong><small>{kind.hint}</small></label><div className="weight-input"><input id={`weight-${kind.id}`} type="number" min="1" max="1000" step="1" required value={Number.isNaN(kind.points) ? "" : kind.points} onChange={(e) => setSettingsDraft((s) => ({ ...s, kinds: s.kinds.map((k, i) => i === index ? { ...k, points: e.target.valueAsNumber } : k) }))} /><span>баллов</span></div></div>; })}<div className="values-notice"><ShieldCheck size={16} /><p>Новые веса применятся к будущим записям. Баллы уже записанных результатов сохранятся.</p></div></section><div className="settings-side"><section className="panel target-panel"><span className="mini-icon mint"><Target size={23} /></span><h2>Дневной ориентир</h2><p>Сколько баллов для тебя означает достаточно насыщенный день?</p><label className="big-number-input"><input aria-label="Дневной ориентир по умолчанию" type="number" min="1" max="10000" step="1" required value={Number.isNaN(settingsDraft.target) ? "" : settingsDraft.target} onChange={(e) => setSettingsDraft((s) => ({ ...s, target: e.target.valueAsNumber }))} /><span>баллов</span></label><p className="target-footnote">Это ориентир для новых дней. На странице дня его можно изменить отдельно.</p><button className="primary-button" type="submit"><Check size={17} />Сохранить настройки</button></section><div className="formula-card"><Sparkles size={21} /><h3>Как считается оценка?</h3><p>Баллы = количество результатов × их вес.</p><p>Прогресс = баллы ÷ дневной ориентир × 100%, максимум 100%.</p><p>Дополнительные баллы сохраняются. Время за компьютером на оценку не влияет.</p></div></div></form><section className="panel backup-panel"><div><h2>Твои записи — у тебя</h2><p>Данные хранятся только в этом браузере. Для переноса на другое устройство скачай резервную копию.</p></div><div><button className="secondary-button" onClick={exportData}><ArrowDownToLine size={16} />Экспорт</button><button className="secondary-button" onClick={() => fileRef.current?.click()}><Upload size={16} />Импорт</button></div></section></>}
      </main>
    </div>
    <input className="sr-only" tabIndex={-1} ref={fileRef} type="file" accept="application/json,.json" onChange={importData} aria-label="Импорт резервной копии" />
    {draft && <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) setDraft(null); }}><section role="dialog" aria-modal="true" aria-labelledby="entry-title" className="modal"><button className="modal-close" aria-label="Закрыть" onClick={() => setDraft(null)}><X size={20} /></button><span className={`modal-symbol ${selectedKind?.color}`}><Plus size={27} /></span><h2 id="entry-title">{editing ? "Изменить результат" : "Ещё один шаг вперёд"}</h2><p className="modal-subtitle">{dayLabel(date, { day: "numeric", month: "long", year: "numeric" })}</p><form onSubmit={saveEntry}><label>Что получилось?<select value={draft.kind} onChange={(e) => setDraft({ ...draft, kind: e.target.value })}>{store.settings.kinds.map((kind) => <option key={kind.id} value={kind.id}>{kind.label} · +{kind.points}</option>)}</select></label><label>Подробности <span className="optional">по желанию</span><input ref={firstField} value={draft.title} maxLength={180} placeholder={["math", "physics", "subject"].includes(draft.kind) ? "Например: контрольная по геометрии" : draft.kind === "contest" ? "Например: Codeforces Round, 3 задачи" : "Например: Codeforces 4A — Watermelon"} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></label><div className="entry-bottom"><label>Количество<input type="number" min="1" max="100" step="1" required value={Number.isNaN(draft.count) ? "" : draft.count} onChange={(e) => setDraft({ ...draft, count: e.target.valueAsNumber })} /></label><div className="entry-total"><span>Добавится к дню</span><strong>+{Number.isFinite(draft.count) ? draft.count * draftPoints : 0}<small> баллов</small></strong></div></div>{draft.kind === "contest" && <p className="field-help">За контест считаем участие и завершение. Решённые задачи можно записать отдельно.</p>}<button className="primary-button modal-submit" type="submit"><Check size={17} />{editing ? "Сохранить изменения" : "Сохранить результат"}</button></form></section></div>}
    {targetDialog && <div className="modal-backdrop" onClick={(e) => { if (e.target === e.currentTarget) setTargetDialog(false); }}><section className="modal small-modal" role="dialog" aria-modal="true" aria-labelledby="target-title"><button className="modal-close" aria-label="Закрыть" onClick={() => setTargetDialog(false)}><X size={20} /></button><span className="modal-symbol mint"><Target size={27} /></span><h2 id="target-title">Ориентир на этот день</h2><p className="modal-subtitle">{dayLabel(date)} · подстрой под свои планы</p><form onSubmit={(e) => { e.preventDefault(); if (!Number.isInteger(targetInput) || targetInput < 1 || targetInput > 10000) return; setStore((s) => ({ ...s, targets: { ...s.targets, [date]: targetInput } })); setTargetDialog(false); notify("Ориентир дня обновлён"); }}><label>Сколько баллов будет достаточно?<input type="number" min="1" max="10000" step="1" required value={Number.isNaN(targetInput) ? "" : targetInput} onChange={(e) => setTargetInput(e.target.valueAsNumber)} /></label><p className="field-help">Можно выбрать небольшой ориентир на день отдыха или большой — на день контеста.</p><button className="primary-button modal-submit" type="submit">Сохранить ориентир</button></form></section></div>}
    {backup && <div className="modal-backdrop"><section className="modal small-modal" role="dialog" aria-modal="true" aria-labelledby="backup-title"><button className="modal-close" aria-label="Закрыть" onClick={() => setBackup(null)}><X size={20} /></button><span className="modal-symbol mint"><Upload size={27} /></span><h2 id="backup-title">Восстановить дневник?</h2><p className="modal-subtitle">В копии {backup.achievements.length} записей. Импорт заменит текущие данные этого браузера.</p><button className="secondary-button full-width" onClick={exportData}>Сначала скачать текущие данные</button><button className="primary-button full-width" onClick={() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(backup)); setStore(backup); setSettingsDraft(backup.settings); setStorageError(""); setBackup(null); notify("Дневник восстановлен"); } catch { notify("Браузер не разрешил сохранить импортированные данные"); } }}>Заменить данные и восстановить</button></section></div>}
    {toast && <div className="toast" role="status"><span><Check size={17} /></span>{toast}{toast === "Запись удалена" && <button onClick={undo}>Отменить</button>}<button aria-label="Закрыть уведомление" onClick={() => setToast("")}><X size={15} /></button></div>}
  </div>;
}
