"use client";
import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, BookOpen, Check, Eye, EyeOff, Link2, LockKeyhole, RefreshCw, ShieldCheck, Unplug } from 'lucide-react';
import type { SchoolGrade } from '../lib/school-import';
type Props = { active: boolean; onGrades: (grades: SchoolGrade[]) => void };
type Connection = { connected: boolean; school?: string; expiresAt?: string | null; grades?: SchoolGrade[]; checkedAt?: string };
class ApiError extends Error { constructor(message: string, public code: string) { super(message); } }
async function api(path: string, body?: object): Promise<Connection> {
  let response: Response;
  try { response = await fetch('/api/schools/' + path, { method: body ? 'POST' : 'GET', credentials: 'same-origin', cache: 'no-store', headers: body ? { 'Content-Type': 'application/json' } : {}, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(55000) }); }
  catch { throw new ApiError('Не удалось связаться с сервером. Проверь интернет и попробуй ещё раз.', 'network'); }
  if (!response.headers.get('content-type')?.includes('application/json')) throw new ApiError('Сервер вернул неподдерживаемый ответ. Обнови страницу и попробуй ещё раз.', 'unexpected_response');
  const result = await response.json();
  if (!response.ok) throw new ApiError(result.message || 'Не удалось выполнить запрос.', result.error || 'server_error');
  return result;
}
export default function SchoolConnection({ active, onGrades }: Props) {
  const [connected, setConnected] = useState(false);
  const [checking, setChecking] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [grades, setGrades] = useState<SchoolGrade[]>([]);
  const [checkedAt, setCheckedAt] = useState('');
  const callback = useRef(onGrades); callback.current = onGrades;
  const linked = useRef(false); const working = useRef(false); const alive = useRef(true);
  function failure(value: unknown) {
    if (!alive.current) return;
    const problem = value instanceof Error ? value : new Error('Не удалось прочитать оценки.'); setError(problem.message);
    if (problem instanceof ApiError && ['session_expired', 'browser_session_missing', 'invalid_credentials'].includes(problem.code)) { setConnected(false); linked.current = false; }
  }
  function accept(result: Connection) {
    if (!alive.current) return;
    linked.current = result.connected; setConnected(result.connected);
    if (result.grades) {
      callback.current(result.grades); setGrades(result.grades); setCheckedAt(result.checkedAt || '');
      setNotice(`Проверено оценок: ${result.grades.length}. Десятки учтены в нужных днях.`);
    }
  }
  async function refresh(quiet = false) {
    if (working.current || !linked.current) return;
    working.current = true; if (!quiet) setBusy(true); setError('');
    try { accept(await api('grades', {})); } catch (err) { failure(err); }
    finally { working.current = false; if (alive.current) setBusy(false); }
  }
  useEffect(() => {
    alive.current = true;
    void api('status').then(async result => { if (!alive.current) return; accept(result); if (result.connected) await refresh(true); }).catch(failure).finally(() => { if (alive.current) setChecking(false); });
    const timer = setInterval(() => { if (document.visibilityState === 'visible') void refresh(true); }, 15 * 60 * 1000);
    const focus = () => { if (document.visibilityState === 'visible') void refresh(true); };
    document.addEventListener('visibilitychange', focus);
    return () => { alive.current = false; clearInterval(timer); document.removeEventListener('visibilitychange', focus); };
  }, []);
  async function connect(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (working.current) return;
    const form = event.currentTarget; const fields = new FormData(form);
    const username = String(fields.get('username') || '').trim(); const password = String(fields.get('password') || '');
    const passwordInput = form.elements.namedItem('password') as HTMLInputElement; passwordInput.value = '';
    working.current = true; setBusy(true); setError(''); setNotice('');
    try { accept(await api('connect', { username, password })); }
    catch (err) { failure(err); }
    finally { working.current = false; if (alive.current) setBusy(false); }
  }
  async function disconnect() {
    if (working.current) return; working.current = true; setBusy(true); setError('');
    try { await api('disconnect', {}); linked.current = false; setConnected(false); setGrades([]); setCheckedAt(''); setNotice('Дневник отключён. Уже добавленные результаты сохранены.'); }
    catch (err) { failure(err); }
    finally { working.current = false; setBusy(false); }
  }
  if (!active) return null;
  return <>
    <section className="page-heading"><div><div className="eyebrow"><span />ОЦЕНКИ БЕЗ РУЧНОГО ВВОДА</div><h1>Твой дневник — рядом.</h1><p>Войди в Schools.by, чтобы десятки сами появлялись в «Своём ритме».</p></div><span className="values-header-icon"><BookOpen size={36} /></span></section>
    <div className="school-grid"><section className="panel school-card"><div className="section-head"><div className="school-title"><span className="mini-icon mint"><BookOpen size={24} /></span><div><h2>Schools.by</h2><span>lyceum.schools.by</span></div></div><span className={`connection-badge ${connected ? 'connected' : ''}`}><i />{checking ? 'Проверяем вход' : connected ? 'Вход сохранён' : 'Не подключён'}</span></div>
      {error && <div className="school-error" role="alert">{error}</div>}
      {notice && !error && <div className="school-notice" role="status"><Check size={16} />{notice}</div>}
      {!connected ? <form className="school-form" onSubmit={connect}><label htmlFor="schools-username">Логин дневника<input id="schools-username" name="username" autoComplete="username" autoCapitalize="none" spellCheck={false} maxLength={200} required placeholder="Твой логин Schools.by" disabled={busy || checking} /></label><label htmlFor="schools-password">Пароль дневника<span className="password-field"><input id="schools-password" name="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" maxLength={500} required placeholder="Пароль от электронного дневника" disabled={busy || checking} /><button type="button" aria-label={showPassword ? 'Скрыть пароль' : 'Показать пароль'} onClick={() => setShowPassword(v => !v)}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></span></label><button className="primary-button" disabled={busy || checking} type="submit">{busy || checking ? <RefreshCw className="spin" size={16} /> : <Link2 size={16} />}{checking ? 'Проверяем подключение…' : busy ? 'Входим и читаем оценки…' : 'Подключить дневник'}</button><p className="school-privacy"><LockKeyhole size={14} />Пароль передаётся Schools.by через сервер «Своего ритма» и не сохраняется. После входа сохраняется только зашифрованная сессия для этого браузера.</p></form> : <div className="school-connected"><div className="connection-success"><span><Check size={24} /></span><h3>Теперь можно просто открывать сайт.</h3><p>Проверяем оценки при открытии и каждые 15 минут, пока страница открыта.</p></div><div className="sync-detail"><span>Последняя успешная проверка</span><strong>{checkedAt ? new Intl.DateTimeFormat('ru-RU', { timeZone: 'Europe/Minsk', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }).format(new Date(checkedAt)) : 'Пока не выполнена'}</strong></div><div className="school-actions"><button className="primary-button" disabled={busy} onClick={() => refresh()}><RefreshCw size={16} className={busy ? 'spin' : ''} />{busy ? 'Проверяем…' : 'Проверить сейчас'}</button><button className="secondary-button" disabled={busy} onClick={disconnect}><Unplug size={16} />Отключить</button></div></div>}
    </section><div className="school-side"><div className="formula-card"><ShieldCheck size={23} /><h3>Баллы начисляются за десятки</h3><p>Математика, алгебра и геометрия используют вес «10 по математике». Физика — свой вес. Остальные предметы — вес обычной десятки.</p><p>Дата берётся из дневника. Повторная проверка не добавляет ту же оценку ещё раз.</p><p>Если ты уже записал десятку вручную, проверь записи на повторы после первого подключения.</p></div><div className="panel school-how"><h3>Что нужно знать</h3><p>Вход сохранится на этом устройстве до 7 дней. Если Schools.by завершит сессию раньше, потребуется снова войти.</p><p>Оценки загружаются за открытую в Schools.by неделю и предыдущую, если её ссылка доступна. Проверки при закрытом сайте пока нет.</p><p>Если дневник недоступен или изменит страницу, покажем ошибку. Ранее сохранённые результаты останутся на месте.</p><a href="https://lyceum.schools.by/" target="_blank" rel="noreferrer">Открыть Schools.by <ArrowUpRight size={13} /></a></div></div></div>
    {connected && grades.length > 0 && <section className="panel school-grades"><div className="section-head"><h2>Последние оценки из дневника</h2><span className="week-range">{grades.length} оценок в проверенных неделях</span></div>{grades.slice(0, 12).map(g => <div className="school-grade" key={g.id}><span className={g.value === 10 ? 'ten' : ''}>{g.value}</span><strong>{g.subject}</strong><small>{new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' }).format(new Date(g.date + 'T12:00:00'))}</small>{g.value === 10 && <span className="grade-counted"><Check size={13} />Учтено</span>}</div>)}</section>}
  </>;
}
