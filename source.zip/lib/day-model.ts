export type Kind = { id: string; label: string; hint: string; points: number; color: string };
export type Settings = { target: number; kinds: Kind[] };
export type Achievement = { id: string; date: string; kind: string; label: string; title: string; count: number; points: number; createdAt: string; sourceId?: string };
export type Store = { version: 1; settings: Settings; achievements: Achievement[]; notes: Record<string, string>; targets: Record<string, number>; ignoredSchoolIds?: string[] };
export const INITIAL_SETTINGS: Settings = { target: 60, kinds: [
  { id: "math", label: "10 по математике", hint: "За понимание и старание", points: 25, color: "lilac" },
  { id: "physics", label: "10 по физике", hint: "Ещё один закон понятен", points: 25, color: "peach" },
  { id: "codeforces", label: "Задача на Codeforces", hint: "Твой следующий accepted", points: 10, color: "mint" },
  { id: "ejudge", label: "Задача на ejudge", hint: "Решение прошло все тесты", points: 10, color: "blue" },
  { id: "subject", label: "10 по другому предмету", hint: "Успехи за пределами точных наук", points: 10, color: "yellow" },
  { id: "contest", label: "Пройденный контест", hint: "Практика в условиях соревнования", points: 30, color: "rose" },
] };
export function dateKey(date = new Date()) { return new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Minsk", year: "numeric", month: "2-digit", day: "2-digit" }).format(date); }
export function shiftDate(date: string, offset: number) { const d = new Date(date + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + offset); return d.toISOString().slice(0, 10); }
export function totalPoints(items: Achievement[]) { return items.reduce((sum, item) => sum + item.points * item.count, 0); }
export function progress(total: number, target: number) { return Math.max(0, Math.min(100, Math.round(total / target * 100))); }
export function validateBackup(input: unknown): Store {
  const s = input as Store;
  const integer = (n: unknown, max: number) => typeof n === "number" && Number.isInteger(n) && n >= 1 && n <= max;
  const text = (v: unknown, max: number) => typeof v === "string" && v.length <= max;
  const validDate = (key: unknown): key is string => typeof key === "string" && /^\d{4}-\d{2}-\d{2}$/.test(key) && Number.isFinite(Date.parse(key + "T12:00:00Z")) && new Date(key + "T12:00:00Z").toISOString().slice(0, 10) === key && key <= dateKey();
  const record = (v: unknown) => !!v && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length <= 20000;
  if (!s || s.version !== 1 || !s.settings || !integer(s.settings.target, 10000) || !Array.isArray(s.settings.kinds) || s.settings.kinds.length !== INITIAL_SETTINGS.kinds.length || !Array.isArray(s.achievements) || s.achievements.length > 50000 || !record(s.notes) || !record(s.targets)) throw new Error("Invalid backup");
  if (new Set(s.settings.kinds.map((k) => k?.id)).size !== INITIAL_SETTINGS.kinds.length || !INITIAL_SETTINGS.kinds.every((k) => s.settings.kinds.some((x) => x?.id === k.id))) throw new Error("Invalid kinds");
  const kinds = s.settings.kinds.map((kind) => { const base = INITIAL_SETTINGS.kinds.find((k) => k.id === kind.id)!; if (!integer(kind.points, 1000)) throw new Error("Invalid weight"); return { ...base, points: kind.points }; });
  if (new Set(s.achievements.map((a) => a?.id)).size !== s.achievements.length) throw new Error("Duplicate records");
  const achievements = s.achievements.map((a) => {
    if (!a || !text(a.id, 100) || !a.id || !validDate(a.date) || !kinds.some((k) => k.id === a.kind) || !text(a.title, 180) || !text(a.label, 100) || !integer(a.count, 100) || !integer(a.points, 1000) || !text(a.createdAt, 50) || !Number.isFinite(Date.parse(a.createdAt))) throw new Error("Invalid record");
    if (a.sourceId !== undefined && (typeof a.sourceId !== 'string' || !/^[a-f0-9]{32}$/.test(a.sourceId))) throw new Error("Invalid source");
    return { id: a.id, date: a.date, kind: a.kind, title: a.title, label: a.label, count: a.count, points: a.points, createdAt: a.createdAt, ...(a.sourceId ? { sourceId: a.sourceId } : {}) };
  });
  const notes: Record<string, string> = {}, targets: Record<string, number> = {};
  for (const [key, value] of Object.entries(s.notes)) { if (!validDate(key) || !text(value, 5000)) throw new Error("Invalid note"); notes[key] = value; }
  for (const [key, value] of Object.entries(s.targets)) { if (!validDate(key) || !integer(value, 10000)) throw new Error("Invalid target"); targets[key] = value; }
  if (s.ignoredSchoolIds !== undefined && (!Array.isArray(s.ignoredSchoolIds) || s.ignoredSchoolIds.length > 50000 || s.ignoredSchoolIds.some(id => typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)))) throw new Error("Invalid ignored sources");
  return { version: 1, settings: { target: s.settings.target, kinds }, achievements, notes, targets, ...(s.ignoredSchoolIds ? { ignoredSchoolIds: [...new Set(s.ignoredSchoolIds)] } : {}) };
}
