import { dateKey, type Store, type Achievement } from './day-model.ts';
export type SchoolGrade = { id: string; date: string; subject: string; value: number };
export function schoolKind(subject: string) {
  const text = subject.toLowerCase();
  if (/математ|алгебр|геометр|матэматы/.test(text)) return 'math';
  if (/физик|фізік/.test(text)) return 'physics';
  return 'subject';
}
export function mergeSchoolGrades(store: Store, input: unknown): Store {
  if (!Array.isArray(input) || input.length > 3000) throw new Error('Invalid grades');
  const grades = input as SchoolGrade[];
  for (const g of grades) {
    if (!g || !/^[a-f0-9]{32}$/.test(g.id) || !/^\d{4}-\d{2}-\d{2}$/.test(g.date) || !Number.isFinite(Date.parse(g.date + 'T12:00:00Z')) || new Date(g.date + 'T12:00:00Z').toISOString().slice(0, 10) !== g.date || g.date > dateKey() || typeof g.subject !== 'string' || !g.subject.trim() || g.subject.length > 160 || !Number.isInteger(g.value) || g.value < 1 || g.value > 10) throw new Error('Invalid grade');
  }
  const latest = new Map(grades.map(g => [g.id, g]));
  const removed = new Set(grades.filter(g => g.value !== 10).map(g => g.id));
  const achievements = store.achievements.filter(a => !a.sourceId || !removed.has(a.sourceId));
  const seen = new Set([...achievements.map(a => a.sourceId).filter(Boolean), ...(store.ignoredSchoolIds || [])]);
  const targets = { ...store.targets };
  for (const g of latest.values()) {
    if (g.value !== 10 || seen.has(g.id)) continue;
    const kind = schoolKind(g.subject); const setting = store.settings.kinds.find(k => k.id === kind)!;
    const item: Achievement = { id: 'schools-' + g.id, date: g.date, kind, label: setting.label, title: `${g.subject}: 10 · Schools.by`, count: 1, points: setting.points, createdAt: new Date().toISOString(), sourceId: g.id };
    achievements.push(item); seen.add(g.id); targets[g.date] ??= store.settings.target;
  }
  return { ...store, achievements, targets };
}
