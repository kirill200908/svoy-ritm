import { Buffer } from 'node:buffer';

const required = ['CLOUDFLARE_API_TOKEN', 'CLOUDFLARE_ACCOUNT_ID', 'SCHOOLS_SESSION_KEY', 'SCHOOLS_PUPIL_ID'];
const missing = required.filter(name => !process.env[name]?.trim());
if (missing.length) {
  console.error('Add these repository Actions secrets before publishing: ' + missing.join(', '));
  process.exit(1);
}
if (!/^[a-f0-9]{32}$/i.test(process.env.CLOUDFLARE_ACCOUNT_ID) || !/^\d{1,12}$/.test(process.env.SCHOOLS_PUPIL_ID)) {
  console.error('Check CLOUDFLARE_ACCOUNT_ID and SCHOOLS_PUPIL_ID. Values are not logged.');
  process.exit(1);
}
if (!/^[A-Za-z0-9+/_-]+={0,2}$/.test(process.env.SCHOOLS_SESSION_KEY) || Buffer.from(process.env.SCHOOLS_SESSION_KEY, 'base64').length !== 32) {
  console.error('SCHOOLS_SESSION_KEY must be a base64-encoded 32-byte key.');
  process.exit(1);
}
console.log('Required deployment configuration is present.');
