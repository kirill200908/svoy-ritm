import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import worker from '../dist/server/index.js';
const env = { SCHOOLS_SESSION_KEY: process.env.SCHOOLS_SESSION_KEY || randomBytes(32).toString('base64'), SCHOOLS_HOST: process.env.SCHOOLS_HOST || 'lyceum.schools.by', SCHOOLS_PUPIL_ID: process.env.SCHOOLS_PUPIL_ID || '' };
const server = createServer(async (req, res) => {
  try {
    const headers = new Headers(); for (const [key,value] of Object.entries(req.headers)) if (value) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    const chunks=[]; let size=0; for await(const chunk of req) { size+=chunk.length; if(size>8192) { res.writeHead(413);res.end();return; } chunks.push(chunk); }
    const request = new Request('http://127.0.0.1:4173'+req.url,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
    const response=await worker.fetch(request,env); const responseHeaders=Object.fromEntries(response.headers); if(response.headers.getSetCookie) responseHeaders['set-cookie']=response.headers.getSetCookie(); res.writeHead(response.status,responseHeaders);res.end(Buffer.from(await response.arrayBuffer()));
  } catch { res.writeHead(500); res.end('Preview request failed'); }
});
server.listen(4173, '127.0.0.1', () => console.log('Local: http://127.0.0.1:4173'));
process.on('SIGINT', () => { server.closeAllConnections(); server.close(() => process.exit(0)); });
