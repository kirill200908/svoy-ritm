import assert from 'node:assert/strict';

const url = new URL(process.env.DEPLOYMENT_URL || '');
assert.equal(url.protocol, 'https:', 'Expected an HTTPS deployment URL');
assert.ok(url.hostname.endsWith('.workers.dev'), 'Expected a workers.dev deployment');
const options = { redirect: 'error', signal: AbortSignal.timeout(20000) };
const page = await fetch(new URL('/', url), options);
assert.equal(page.status, 200, 'The published page must load');
assert.match(await page.text(), /Свой ритм/);
const status = await fetch(new URL('/api/schools/status', url), options);
assert.equal(status.status, 200, 'The diary form must work without ChatGPT sign-in');
assert.equal((await status.json()).connected, false, 'An anonymous browser must have no diary access');
const cookies = status.headers.getSetCookie();
const browser = cookies.find(value => value.startsWith('__Secure-rhythm-browser='));
assert.ok(browser && /HttpOnly/.test(browser) && /Secure/.test(browser) && /SameSite=Strict/.test(browser), 'The browser session must use protected cookies');
const grades = await fetch(new URL('/api/schools/grades', url), {
  ...options, method: 'POST',
  headers: { Origin: url.origin, Cookie: browser.split(';')[0], 'Content-Type': 'application/json' },
  body: '{}',
});
assert.equal(grades.status, 401, 'Anonymous requests must not expose grades');
assert.equal((await grades.json()).error, 'session_expired');
console.log('Published page and anonymous diary isolation verified.');
