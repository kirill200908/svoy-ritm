import { build } from 'esbuild';
import { mkdir, writeFile, copyFile, readFile } from 'node:fs/promises';
import path from 'node:path';
import { existsSync, readFileSync, realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
// Resolve authored files in Node so the native bundler need not enumerate parent directories.
const sourceRoot = process.cwd();
const dependencyRoot = realpathSync(path.join(sourceRoot, 'node_modules'));
const localFiles = { name: 'local-source', setup(api) {
  api.onResolve({ filter: /.*/ }, args => {
    if (/^https?:/.test(args.path)) return { path: args.path, external: true };
    let file;
    if (path.isAbsolute(args.path) || args.path.startsWith('.')) {
      const base = path.resolve(args.resolveDir || sourceRoot, args.path);
      file = ['', '.tsx', '.ts', '.js', '.json', '/index.tsx', '/index.js'].map(ext => base + ext).find(candidate => existsSync(candidate));
    } else if (args.path === 'lucide-react') {
      const folder = path.join(sourceRoot, 'node_modules', 'lucide-react');
      file = path.join(folder, JSON.parse(readFileSync(path.join(folder, 'package.json'), 'utf8')).module);
    } else { file = createRequire(path.join(args.resolveDir || sourceRoot, '__resolve.cjs')).resolve(args.path); }
    if (!file || ![sourceRoot, dependencyRoot].some(root => file.startsWith(root + path.sep))) throw new Error('Unresolved local source: ' + args.path);
    return { path: file, namespace: 'local-source', ...(file.includes(path.sep + 'lucide-react' + path.sep) ? { sideEffects: false } : {}) };
  });
  api.onLoad({ filter: /.*/, namespace: 'local-source' }, args => ({ contents: readFileSync(args.path, 'utf8'), loader: ({ '.tsx': 'tsx', '.ts': 'ts', '.css': 'css', '.json': 'json' })[path.extname(args.path)] || 'js', resolveDir: path.dirname(args.path) }));
} };
await mkdir('dist/assets', { recursive: true });
await build({ absWorkingDir: process.cwd(), entryPoints: [path.resolve('main.tsx')], tsconfigRaw: { compilerOptions: { jsx: 'react-jsx', target: 'es2022' } }, plugins: [localFiles], bundle: true, minify: true, format: 'esm', target: ['es2022'], jsx: 'automatic', outfile: 'dist/assets/app.js', define: { 'process.env.NODE_ENV': '"production"' }, legalComments: 'linked', logLevel: 'info' });
await copyFile('public/favicon.svg', 'dist/favicon.svg');
await writeFile('dist/index.html', `<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#285344"><title>Свой ритм — день по твоим ценностям</title><meta name="description" content="Дневник твоего прогресса: десятки по математике и физике, задачи на Codeforces и ejudge, контесты. Твои ценности, твои ориентиры."><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/assets/app.css"></head><body><div id="root"></div><noscript>Для работы дневника включи JavaScript в браузере.</noscript><script type="module" src="/assets/app.js"></script></body></html>`);
console.log('Static site built in dist/');
const assets = {};
for (const [url, file, type] of [['/index.html','dist/index.html','text/html; charset=utf-8'],['/assets/app.js','dist/assets/app.js','text/javascript; charset=utf-8'],['/assets/app.css','dist/assets/app.css','text/css; charset=utf-8'],['/assets/app.js.LEGAL.txt','dist/assets/app.js.LEGAL.txt','text/plain; charset=utf-8'],['/favicon.svg','dist/favicon.svg','image/svg+xml']]) assets[url] = { body: await readFile(file, 'utf8'), type };
await mkdir('.build', { recursive: true });
await writeFile('.build/worker-entry.mjs', `import { createWorker } from '../worker/index.mjs';\nexport default createWorker(${JSON.stringify(assets)});\n`);
await mkdir('dist/server', { recursive: true });
await build({ absWorkingDir: sourceRoot, entryPoints: [path.resolve('.build/worker-entry.mjs')], plugins: [localFiles], bundle: true, minify: true, format: 'esm', target: ['es2022'], outfile: 'dist/server/index.js', legalComments: 'none', logLevel: 'info' });
console.log('Server-backed site built in dist/server/index.js');
